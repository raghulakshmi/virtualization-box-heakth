#!/usr/bin/env bash
set -euo pipefail
cd /opt/driveit-health
printf '\n== Containers ==\n'
docker compose ps
printf '\n== Collector timer ==\n'
systemctl --no-pager status driveit-libvirt-collector.timer | head -n 12 || true
printf '\n== Collector metric file ==\n'
ls -lh /var/lib/driveit-health/textfile/libvirt.prom
printf '\n== VM metrics ==\n'
grep -E '^driveit_vm_(running|cpu_seconds_total)' /var/lib/driveit-health/textfile/libvirt.prom | head -n 20
printf '\n== Prometheus health ==\n'
curl -fsS http://127.0.0.1:9090/-/ready && echo
printf '\n== Grafana health ==\n'
curl -fsS http://127.0.0.1:3000/api/health && echo
