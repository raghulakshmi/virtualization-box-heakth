#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run: sudo ./install.sh'; exit 1; fi
if ! command -v docker >/dev/null || ! docker compose version >/dev/null 2>&1; then
  echo 'Docker Engine and Docker Compose plugin are required. Nothing installed.'; exit 1
fi
if ! command -v virsh >/dev/null; then echo 'virsh is required. Nothing installed.'; exit 1; fi
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DST=/opt/driveit-health
if [[ "$SRC" != "$DST" ]]; then
  if [[ -e "$DST" ]]; then echo "$DST already exists. Back it up or remove it before installing."; exit 1; fi
  mkdir -p "$DST"
  cp -a "$SRC"/. "$DST"/
fi
mkdir -p /var/lib/driveit-health/textfile
chmod 755 /var/lib/driveit-health /var/lib/driveit-health/textfile
if [[ ! -f "$DST/.env" ]]; then
  PASSWORD="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(24))
PY
)"
  printf 'GRAFANA_ADMIN_PASSWORD=%s\n' "$PASSWORD" > "$DST/.env"
  chmod 600 "$DST/.env"
  echo 'Grafana username: admin'
  echo "Grafana initial password: $PASSWORD"
  echo 'Store this password securely. It will not be printed again.'
fi
install -m 0644 "$DST/systemd/driveit-libvirt-collector.service" /etc/systemd/system/
install -m 0644 "$DST/systemd/driveit-libvirt-collector.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now driveit-libvirt-collector.timer
systemctl start driveit-libvirt-collector.service
cd "$DST"
docker compose up -d
echo 'Installed. Open via SSH tunnel: ssh -L 3000:127.0.0.1:3000 <user>@<host>'
echo 'Then browse http://localhost:3000'
echo 'Run: sudo /opt/driveit-health/verify.sh'
