#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo'; exit 1; fi
cd /opt/driveit-health
systemctl disable --now driveit-libvirt-collector.timer || true
systemctl stop driveit-libvirt-collector.service || true
rm -f /etc/systemd/system/driveit-libvirt-collector.timer /etc/systemd/system/driveit-libvirt-collector.service
systemctl daemon-reload
docker compose down
printf '\nStopped and removed service containers. Prometheus/Grafana Docker volumes and /opt/driveit-health retained for data safety.\n'
printf 'To remove monitoring data later, review Docker volumes manually; this script never deletes them.\n'
