# DriveIT Virtualization Health — v1

A read-only, single-host KVM monitoring stack for `driveit-server`, with DriveIT Technologies branding, five provisioned Grafana dashboards, Prometheus and host/libvirt collection.

## Requirements

- Ubuntu host with `virsh`, systemd and Python 3
- Docker Engine with `docker compose` plugin, and access to pull container images
- Root access for installation; sufficient space for 30 days of metrics
- SSH access to the host from your workstation

## Install

```bash
unzip driveit-health-v1.zip
cd driveit-health-v1
sudo ./install.sh
sudo /opt/driveit-health/verify.sh
```

The installer prints a generated initial Grafana admin password **once**. Keep it securely. The stack listens on host loopback only; it does not expose Grafana/Prometheus to the LAN or internet.

From your laptop, use an SSH tunnel:

```bash
ssh -L 3000:127.0.0.1:3000 driveit@YOUR_HOST_IP
```

Then open `http://localhost:3000` and log in as `admin`.

## Dashboards

1. Infrastructure Overview
2. Ubuntu Host Performance
3. Virtual Machine Performance (VM selector)
4. Storage & Network
5. Resource Correlation (VM selector)

Dashboard images include the user-provided DriveIT Technologies logo. Grafana's application-wide login branding is not replaced; that requires different licensing/customization. The logo appears within the provisioned dashboards.

## Important measurement limitations

- Host exporter reads `/proc` and `/sys`; the collector reads libvirt via `virsh` only.
- VM CPU counters are cumulative; Prometheus calculates rates. VM CPU usage is QEMU domain CPU time, not just guest vCPU time.
- VM RAM maximum/current are *allocation*, not Windows/Linux guest RAM utilization. QEMU RSS is not equal to actual guest-used memory.
- `balloon.usable` is shown only when the guest supplies a valid statistic. No guest agent is installed.
- VM disk and NIC counters may be missing depending on libvirt/device capabilities. Missing is not zero.
- Kernel block-device I/O and virtual disk I/O are different layers and should not be summed as one total.
- Prometheus alerts are configured and visible in Prometheus; **external notifications are not configured** in v1. Set up Alertmanager or Grafana contact points separately.
- No Windows Event Log/BSOD ingestion in v1; no root-cause attribution is claimed.
- Monitoring is not a replacement for memtest, dump analysis, or hardware diagnostics.

## Services and security

- Grafana: `127.0.0.1:3000`
- Prometheus: `127.0.0.1:9090`
- Node Exporter: Docker internal network only
- Libvirt collector: host systemd timer, runs every ~15s, writes an atomic `.prom` textfile
- Prometheus retention: 30 days
- Docker container memory limits: Grafana 800 MiB, Prometheus 1.2 GiB, Node Exporter 256 MiB (limits, not reservations)
- No VM control operations, no privileged Docker socket access, no public listener

## Diagnostics

```bash
sudo /opt/driveit-health/verify.sh
sudo journalctl -u driveit-libvirt-collector.service -n 50 --no-pager
cd /opt/driveit-health && sudo docker compose logs --tail=50
```

## Remove

```bash
sudo /opt/driveit-health/uninstall.sh
```

This stops the services but intentionally preserves metric volumes and the installed directory.

## Initial validation checklist

- Confirm all six VMs appear in the running-state graph.
- Confirm `win-vm-01` CPU consumption approximately tracks `virsh domstats` over the same interval.
- Confirm host CPU approximately matches `sar` / `mpstat` for comparable windows.
- Check disk and network series for each VM; some virtual devices may not expose all counters.
- Check dashboard logo and Grafana login over the SSH tunnel.
- Check Prometheus `/rules` and `/alerts`; adjust thresholds before relying on alerts.

