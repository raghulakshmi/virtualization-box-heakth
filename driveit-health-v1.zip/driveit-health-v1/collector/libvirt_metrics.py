#!/usr/bin/env python3
"""Read-only libvirt metrics snapshot for Prometheus node_exporter textfile collector.
Runs as root on the KVM host, writes metrics atomically, no persistent credentials.
"""
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

OUT = Path('/var/lib/driveit-health/textfile/libvirt.prom')
SAFE = re.compile(r'[^a-zA-Z0-9_:]')

def run(*args):
    return subprocess.check_output(['virsh', *args], text=True, stderr=subprocess.PIPE, timeout=25)

def escape(value):
    return str(value).replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

def emit(lines, name, value, **labels):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return
    labelstr = '{' + ','.join(f'{k}="{escape(v)}"' for k, v in labels.items()) + '}' if labels else ''
    lines.append(f'{name}{labelstr} {number:g}')

def main():
    lines = [f'# DriveIT libvirt collection at {int(time.time())}']
    output = run('domstats', '--list-running', '--cpu-total', '--balloon', '--block', '--interface')
    domains = {}
    current = None
    for raw in output.splitlines():
        s = raw.strip()
        if s.startswith('Domain:'):
            m = re.match(r"Domain:\s*'([^']+)'", s)
            if m:
                current = m.group(1)
                domains[current] = {}
        elif current and '=' in s:
            k, v = s.split('=', 1)
            domains[current][k] = v
    try:
        all_names = [n.strip() for n in run('list', '--all', '--name').splitlines() if n.strip()]
    except Exception:
        all_names = list(domains)
    for vm in all_names:
        emit(lines, 'driveit_vm_running', 1 if vm in domains else 0, vm=vm)
    for vm, data in domains.items():
        for key, metric, divisor in [
            ('cpu.time','driveit_vm_cpu_seconds_total',1e9),
            ('cpu.user','driveit_vm_cpu_user_seconds_total',1e9),
            ('cpu.system','driveit_vm_cpu_system_seconds_total',1e9),
            ('balloon.maximum','driveit_vm_memory_maximum_bytes',1/1024),
            ('balloon.current','driveit_vm_memory_current_bytes',1/1024),
            ('balloon.rss','driveit_vm_qemu_rss_bytes',1/1024),
            ('balloon.available','driveit_vm_guest_available_bytes',1/1024),
            ('balloon.unused','driveit_vm_guest_unused_bytes',1/1024),
            ('balloon.usable','driveit_vm_guest_usable_bytes',1/1024),
        ]:
            if key in data:
                emit(lines, metric, float(data[key])/divisor, vm=vm)
        for kind in ('block', 'net'):
            indexes = set()
            for k in data:
                m = re.match(rf'{kind}\.(\d+)\.', k)
                if m: indexes.add(m.group(1))
            for i in indexes:
                if kind == 'block':
                    dev = data.get(f'block.{i}.name', data.get(f'block.{i}.path', i))
                    for src, metric in [('rd.bytes','driveit_vm_disk_read_bytes_total'),('wr.bytes','driveit_vm_disk_write_bytes_total'),('rd.reqs','driveit_vm_disk_read_ops_total'),('wr.reqs','driveit_vm_disk_write_ops_total'),('rd.times','driveit_vm_disk_read_time_seconds_total'),('wr.times','driveit_vm_disk_write_time_seconds_total')]:
                        key = f'block.{i}.{src}'
                        if key in data:
                            val = float(data[key]) / (1e9 if src.endswith('times') else 1)
                            emit(lines, metric, val, vm=vm, disk=dev)
                else:
                    iface = data.get(f'net.{i}.name', i)
                    for src, metric in [('rx.bytes','driveit_vm_network_receive_bytes_total'),('tx.bytes','driveit_vm_network_transmit_bytes_total'),('rx.pkts','driveit_vm_network_receive_packets_total'),('tx.pkts','driveit_vm_network_transmit_packets_total'),('rx.errs','driveit_vm_network_receive_errors_total'),('tx.errs','driveit_vm_network_transmit_errors_total'),('rx.drop','driveit_vm_network_receive_drops_total'),('tx.drop','driveit_vm_network_transmit_drops_total')]:
                        key = f'net.{i}.{src}'
                        if key in data: emit(lines, metric, data[key], vm=vm, interface=iface)
    emit(lines, 'driveit_libvirt_collection_success', 1)
    emit(lines, 'driveit_libvirt_collection_timestamp_seconds', time.time())
    OUT.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.libvirt-', suffix='.prom', dir=OUT.parent)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write('\n'.join(lines)+'\n')
        os.chmod(tmp, 0o644)
        os.replace(tmp, OUT)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(f'ERROR: libvirt collection failed: {exc}', file=sys.stderr)
        sys.exit(1)
